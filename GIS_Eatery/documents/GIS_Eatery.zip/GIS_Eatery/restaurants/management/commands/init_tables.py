from django.core.management.base import BaseCommand
from restaurants.models import Restaurant, Table

class Command(BaseCommand):
    help = 'Tự động kê bàn ghế cho các quán ăn'

    def handle(self, *args, **kwargs):
        restaurants = Restaurant.objects.all()
        
        if not restaurants.exists():
            self.stdout.write(self.style.WARNING("⚠️ Chưa có quán ăn nào. Hãy chạy lệnh init_data trước!"))
            return

        count = 0
        for r in restaurants:
            # Kiểm tra xem quán đã có bàn chưa
            if Table.objects.filter(restaurant=r).exists():
                self.stdout.write(f"ℹ️ Quán '{r.name}' đã có bàn, bỏ qua.")
                continue

            # Nếu chưa có, tạo tự động 10 bàn
            self.stdout.write(f"🔨 Đang đóng bàn ghế cho: {r.name}...")
            for i in range(1, 11): # Tạo 10 bàn từ số 1 đến 10
                # Bàn 1-4: Bàn nhỏ (2 người)
                # Bàn 5-8: Bàn vừa (4 người)
                # Bàn 9-10: Bàn lớn (10 người)
                capacity = 4
                if i <= 4: capacity = 2
                elif i >= 9: capacity = 10

                Table.objects.create(
                    restaurant=r,
                    table_number=f"Bàn {i}",
                    capacity=capacity
                )
            count += 1
        
        self.stdout.write(self.style.SUCCESS(f"✅ HOÀN TẤT! Đã thêm bàn ghế cho {count} quán mới."))