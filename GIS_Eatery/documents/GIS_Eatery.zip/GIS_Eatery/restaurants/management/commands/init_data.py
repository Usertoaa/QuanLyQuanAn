import os
import requests
from django.core.management.base import BaseCommand
from django.core.files.base import ContentFile
from django.contrib.gis.geos import Point
from restaurants.models import Restaurant, Dish

class Command(BaseCommand):
    help = 'Nhập dữ liệu mẫu chuẩn hóa (Xóa cũ -> Tạo mới)'

    def handle(self, *args, **kwargs):
        self.stdout.write("♻️ Đang dọn dẹp dữ liệu cũ...")
        # 1. Xóa sạch dữ liệu cũ để tránh trùng lặp/rác
        Restaurant.objects.all().delete()
        
        self.stdout.write("⏳ Đang tải dữ liệu mới (kèm hình ảnh)...")

        # 2. Danh sách dữ liệu CHUẨN (Mã quận phải khớp với models.py)
        data = [
            # --- QUẬN 3 ---
            {
                "name": "Phở Hòa Pasteur",
                "address": "260C Pasteur, Phường 8",
                "district": "3",  # Mã '3' -> Hiển thị 'Quận 3'
                "lat": 10.7829, "lng": 106.6896,
                "image_url": "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=800",
                "menu": [
                    {"name": "Phở Chín Nạm", "price": 95000, "img": "https://images.unsplash.com/photo-1582878826629-29b7ad1cdc43?w=400"},
                    {"name": "Phở Tái Gầu", "price": 95000, "img": "https://images.unsplash.com/photo-1559314809-0d155014e29e?w=400"},
                    {"name": "Quẩy giòn", "price": 10000, "img": "https://plus.unsplash.com/premium_photo-1694699355720-3023fb18c34f?w=400"},
                ]
            },
            # --- QUẬN 1 ---
            {
                "name": "Bánh Mì Huỳnh Hoa",
                "address": "26 Lê Thị Riêng, P. Phạm Ngũ Lão",
                "district": "1", # Mã '1' -> Hiển thị 'Quận 1'
                "lat": 10.7715, "lng": 106.6942,
                "image_url": "https://images.unsplash.com/photo-1629831966000-d29e3a6c116c?w=800",
                "menu": [
                    {"name": "Bánh Mì Đặc Biệt", "price": 68000, "img": "https://images.unsplash.com/photo-1629831966000-d29e3a6c116c?w=400"},
                    {"name": "Chả Lụa (100g)", "price": 40000, "img": "https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400"},
                ]
            },
            {
                "name": "Pizza 4P's Bến Thành",
                "address": "8 Thủ Khoa Huân, P. Bến Thành",
                "district": "1",
                "lat": 10.7725, "lng": 106.6980,
                "image_url": "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=800",
                "menu": [
                    {"name": "Pizza 4 Cheese", "price": 280000, "img": "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400"},
                    {"name": "Mì Ý Cua", "price": 250000, "img": "https://images.unsplash.com/photo-1563379926898-05f4575a45d8?w=400"},
                ]
            },
            {
                "name": "Katinat Saigon Kafe",
                "address": "91 Đồng Khởi, P. Bến Nghé",
                "district": "1",
                "lat": 10.7758, "lng": 106.7032,
                "image_url": "https://images.unsplash.com/photo-1559496417-e7f25cb247f3?w=800",
                "menu": [
                    {"name": "Trà Sữa Chôm Chôm", "price": 55000, "img": "https://images.unsplash.com/photo-1559496417-e7f25cb247f3?w=400"},
                    {"name": "Cà Phê Sữa Đá", "price": 45000, "img": "https://images.unsplash.com/photo-1578314675249-a6910f80cc4e?w=400"},
                ]
            },
            # --- QUẬN 5 ---
            {
                "name": "Dim Tu Tac (Dimsum)",
                "address": "29B Trần Hưng Đạo, P.6",
                "district": "5",
                "lat": 10.7538, "lng": 106.6781,
                "image_url": "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=800",
                "menu": [
                    {"name": "Há Cảo Tôm", "price": 68000, "img": "https://images.unsplash.com/photo-1563245372-f21724e3856d?w=400"},
                    {"name": "Bánh Bao Kim Sa", "price": 55000, "img": "https://images.unsplash.com/photo-1615937657715-bc7b4b7962c1?w=400"},
                    {"name": "Vịt Quay Bắc Kinh", "price": 450000, "img": "https://images.unsplash.com/photo-1579888944880-d98341245702?w=400"},
                ]
            },
            # --- PHÚ NHUẬN ---
            {
                "name": "Cơm Tấm Ba Ghiền",
                "address": "84 Đặng Văn Ngữ, P.10",
                "district": "PN",
                "lat": 10.7991, "lng": 106.6759,
                "image_url": "https://images.unsplash.com/photo-1595903273160-c117d8481358?w=800",
                "menu": [
                    {"name": "Cơm Sườn Bì Chả", "price": 85000, "img": "https://images.unsplash.com/photo-1595903273160-c117d8481358?w=400"},
                    {"name": "Cơm Sườn Cây", "price": 110000, "img": "https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400"},
                ]
            },
            # --- BÌNH THẠNH ---
            {
                "name": "Gà Nướng Anh Tư",
                "address": "449 Lê Quang Định, P.5",
                "district": "BT",
                "lat": 10.8166, "lng": 106.6891,
                "image_url": "https://images.unsplash.com/photo-1606728035253-49e8a23146de?w=800",
                "menu": [
                    {"name": "Gà Nướng", "price": 160000, "img": "https://images.unsplash.com/photo-1606728035253-49e8a23146de?w=400"},
                    {"name": "Bánh Mì Mật Ong", "price": 5000, "img": "https://images.unsplash.com/photo-1550547660-d9450f859349?w=400"},
                ]
            },
             # --- GÒ VẤP ---
            {
                "name": "Bánh Cuốn Nóng Ngọc Mỹ",
                "address": "Kiot 44 Chợ Hạnh Thông Tây",
                "district": "GV",
                "lat": 10.8340, "lng": 106.6575,
                "image_url": "https://images.unsplash.com/photo-1513268817757-194451636284?w=800",
                "menu": [
                    {"name": "Bánh Cuốn Đặc Biệt", "price": 35000, "img": "https://images.unsplash.com/photo-1513268817757-194451636284?w=400"},
                ]
            }
        ]

        for item in data:
            restaurant = Restaurant.objects.create(
                name=item['name'],
                address=item['address'],
                district=item['district'],
                location=Point(item['lng'], item['lat']),
            )
            
            self.stdout.write(f"➕ Đang tạo: {item['name']}...")
            self.download_and_save_image(item['image_url'], restaurant)
            restaurant.save()

            for dish_data in item['menu']:
                dish = Dish.objects.create(
                    restaurant=restaurant,
                    name=dish_data['name'],
                    price=dish_data['price'],
                    is_available=True
                )
                self.download_and_save_image(dish_data['img'], dish)
                dish.save()

        self.stdout.write(self.style.SUCCESS("✅ ĐÃ NHẬP XONG! Dữ liệu đã đồng nhất."))

    def download_and_save_image(self, url, instance):
        try:
            response = requests.get(url, timeout=10)
            if response.status_code == 200:
                file_name = url.split("?")[0].split("/")[-1] + ".jpg"
                instance.image.save(file_name, ContentFile(response.content), save=False)
        except Exception:
            pass # Bỏ qua nếu lỗi ảnh